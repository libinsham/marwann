"use client";

import { useState } from "react";
import India from "@svg-maps/india";
import { stateData } from "@/components/home/reachData";

export default function IndiaMap({
  selectedState,
  onStateSelect,
}) {
  const [hoveredState, setHoveredState] = useState("");

  const hoveredData = hoveredState
    ? stateData[hoveredState]
    : null;

  const handleStateClick = (stateName) => {
    onStateSelect?.(stateName);
  };

  return (
    <div className="marwann-india-map-wrap">

      {/* =====================================================
          FIXED TOOLTIP CONTAINER
          Always exists — only visibility changes.
          Therefore the map NEVER moves when tooltip appears.
      ===================================================== */}

      <div
        className={`marwann-india-map-tooltip ${
          hoveredState ? "is-visible" : ""
        }`}
        aria-hidden={!hoveredState}
      >
        <strong>
          {hoveredState || "\u00A0"}
        </strong>

        <span>
          {hoveredData
            ? `${hoveredData.members} DB Members • ${
                hoveredData.centres
              } Approved ${
                hoveredData.centres === 1
                  ? "Center"
                  : "Centers"
              }`
            : "\u00A0"}
        </span>
      </div>

      {/* =====================================================
          MAP
      ===================================================== */}

      <div className="marwann-india-map-stage">

        <svg
          className="marwann-india-map-svg"
          viewBox={India.viewBox}
          role="img"
          aria-label="Interactive map of India"
        >
          {India.locations.map((location) => {
            const isSelected =
              selectedState === location.name;

            const isHovered =
              hoveredState === location.name;

            /*
             * IMPORTANT:
             * Color is controlled directly here.
             * This prevents main.css from turning the map black.
             */

            let fillColor = "#075d56";

            /*
             * Clicked state = yellow
             */
            if (isSelected) {
              fillColor = "#f7d95d";
            }

            /*
             * Hover = white
             */
            if (isHovered) {
              fillColor = "#ffffff";
            }

            let strokeColor = "#ffffff";

            if (isSelected || isHovered) {
              strokeColor = "#075d56";
            }

            return (
              <path
                key={location.id}
                d={location.path}
                className={[
                  "marwann-india-map-location",
                  isSelected
                    ? "is-selected"
                    : "",
                  isHovered
                    ? "is-hovered"
                    : "",
                ]
                  .filter(Boolean)
                  .join(" ")}

                /*
                 * INLINE STYLE:
                 * This is the important part.
                 */
                style={{
                  fill: fillColor,
                  stroke: strokeColor,
                  strokeWidth: 1.15,
                  vectorEffect:
                    "non-scaling-stroke",
                  cursor: "pointer",
                  opacity: 1,
                }}

                onMouseEnter={() => {
                  setHoveredState(
                    location.name
                  );
                }}

                onMouseLeave={() => {
                  setHoveredState("");
                }}

                onFocus={() => {
                  setHoveredState(
                    location.name
                  );
                }}

                onBlur={() => {
                  setHoveredState("");
                }}

                onClick={() => {
                  handleStateClick(
                    location.name
                  );
                }}

                onKeyDown={(event) => {
                  if (
                    event.key === "Enter" ||
                    event.key === " "
                  ) {
                    event.preventDefault();

                    handleStateClick(
                      location.name
                    );
                  }
                }}

                tabIndex={0}
                role="button"
                aria-label={location.name}
              />
            );
          })}
        </svg>
      </div>

      {/* =====================================================
          SELECTED STATE
      ===================================================== */}

      <div
        className="marwann-india-map-status"
        aria-live="polite"
      >
        <span>Selected</span>

        <span className="status-dot">
          •
        </span>

        <strong>
          {selectedState ||
            "Click a state to explore"}
        </strong>
      </div>
    </div>
  );
}