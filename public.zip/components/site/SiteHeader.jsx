'use client'

/* eslint-disable @next/next/no-img-element */
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { navClass } from '@/lib/nav'
import { DEFAULT_SETTINGS, toTel } from '@/lib/shared'
export default function SiteHeader({ topText = 'We Serve God by Serving Others', settings = DEFAULT_SETTINGS }) {
  const pathname = usePathname()
  return (
    <>
      <header className="header-section-1">
        <div className="top-bar d-none d-md-block">
          <div className="container-fluid">
            <div className="row">
              <div className="col-xl-12">
                <div className="top-bar-content text-center">
                  <div className="text-wrap">
                    <img src="/assets/img/icons/calendar-time.svg" alt="" />
                  </div>
                  <Link href="/donate" className="e-primary-btn is-hover-white top-btn">Donate Now</Link>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="header-bottom-layout-2">
          <div className="header-left">
            <div className="logo-wrap-2">
              <Link href="/">
                <img src="/assets/img/logo/logo.png" alt="MARWANN CHARITABLE TRUST" />
              </Link>
            </div>
          </div>
          <div className="w-100 d-none d-xl-block">
            <div className="header-middle">
              <nav className="main-menu-2 d-none d-xl-block" aria-label="Main navigation">
                <ul>
                  <li className={navClass("", pathname, ["/"])}>
                    <Link href="/">Home</Link>
                  </li>
                  <li className={navClass("has-dropdown", pathname, ["/about", "/leadership", "/legal-recognition", "/our-story", "/timeline"])}>
                    <Link href="/about">About</Link>
                    <ul className="sub-menu">
                      <li className={navClass("", pathname, ["/about"])}>
                        <Link href="/about">About Us</Link>
                      </li>
                      <li className={navClass("", pathname, ["/our-story"])}>
                        <Link href="/our-story">Our Story</Link>
                      </li>
                      <li className={navClass("", pathname, ["/leadership"])}>
                        <Link href="/leadership">Leadership</Link>
                      </li>
                      <li className={navClass("", pathname, ["/timeline"])}>
                        <Link href="/timeline">Our Timeline</Link>
                      </li>
                      <li className={navClass("", pathname, ["/legal-recognition"])}>
                        <Link href="/legal-recognition">{"Legal & Recognition"}</Link>
                      </li>
                    </ul>
                  </li>
                  <li className={navClass("has-dropdown", pathname, ["/active-campaigns", "/gallery", "/program-areas"])}>
                    <Link href="/program-areas">Work</Link>
                    <ul className="sub-menu">
                      <li className={navClass("", pathname, ["/program-areas"])}>
                        <Link href="/program-areas">Program Areas</Link>
                      </li>
                      <li className={navClass("", pathname, ["/active-campaigns"])}>
                        <Link href="/active-campaigns">Active Campaigns</Link>
                      </li>
                      <li className={navClass("", pathname, ["/gallery"])}>
                        <Link href="/gallery">Photo Gallery</Link>
                      </li>
                    </ul>
                  </li>
                  <li className={navClass("has-dropdown", pathname, ["/crowdfunding", "/donate", "/events", "/volunteer"])}>
                    <a href="#">Engage</a>
                    <ul className="sub-menu">
                      <li className={navClass("", pathname, ["/donate"])}>
                        <Link href="/donate">Donate</Link>
                      </li>
                      <li className={navClass("", pathname, ["/crowdfunding"])}>
                        <Link href="/crowdfunding">Crowdfunding</Link>
                      </li>
                      <li className={navClass("", pathname, ["/volunteer"])}>
                        <Link href="/volunteer">Volunteer</Link>
                      </li>
                      <li className={navClass("", pathname, ["/events"])}>
                        <Link href="/events">Events</Link>
                      </li>
                    </ul>
                  </li>
                  <li className={navClass("", pathname, ["/contact"])}>
                    <Link href="/contact">Contact</Link>
                  </li>
                </ul>
              </nav>
              <div className="header-info-wrap">
                <div className="header-info-3 d-none d-xl-flex">
                  <div className="header-info-icon">
                    <i className="fa-regular fa-phone-volume"></i>
                  </div>
                  <div className="header-info-content">
                    <span>Contact Us!</span>
                    <p>
                      <Link href="/contact">Get in Touch</Link>
                    </p>
                  </div>
                </div>
                <div className="header-btn-wrap d-none d-xl-flex">
                  <Link href="/donate" className="e-primary-btn has-icon">
                    Donate Now
                    {" "}
                    <span className="icon-wrap">
                      <span className="icon">
                        <i className="fa-regular fa-arrow-right"></i>
                        <i className="fa-regular fa-arrow-right"></i>
                      </span>
                    </span>
                  </Link>
                </div>
              </div>
            </div>
          </div>
          <div className="header-right">
            <div className="header-bar-3 d-none d-xl-flex" data-toggle="sidebar">
              <div className="bar bar-1"></div>
              <div className="bar bar-2"></div>
              <div className="bar bar-3"></div>
            </div>
            <div className="header-bar-3 d-xl-none" data-toggle="menubar">
              <div className="bar bar-1"></div>
              <div className="bar bar-2"></div>
              <div className="bar bar-3"></div>
            </div>
          </div>
        </div>
      </header>
      <div className="off-canvas-sidebar">
        <div className="off-canvas-sidebar-body">
          <div className="off-canvas-sidebar-close" data-close="sidebar">
            <i className="fa-regular fa-xmark"></i>
          </div>
          <div className="off-canvas-logo m-b-20">
            <Link href="/">
              <img src="/assets/img/logo/logo.svg" alt="MARWANN CHARITABLE TRUST" />
            </Link>
          </div>
          <div className="off-canvas-text m-b-30">
            <p>
              MARWANN CHARITABLE TRUST serves communities through education, healthcare, social welfare and humanitarian support. {topText}.
            </p>
          </div>
          <div className="off-canvas-thumb m-b-40">
            <img src="/assets/img/thumbs/thumb-3.webp" alt="Community service" />
          </div>
          <div className="off-canvas-contact m-b-40">
            <Link href="/contact" className="off-canvas-contact-item">
              <div className="icon">
                <i className="fa-solid fa-location-dot"></i>
              </div>
              <div className="text">
                <h6>Address</h6>
                <p>{settings.shortAddress}</p>
              </div>
            </Link>
            {" "}
            <a href={`mailto:${settings.email}`} className="off-canvas-contact-item">
              <div className="icon">
                <i className="fa-solid fa-paper-plane"></i>
              </div>
              <div className="text">
                <h6>Email</h6>
                <p>Contact Our Team</p>
              </div>
            </a>
            {" "}
            <a href={toTel(settings.phones[0])} className="off-canvas-contact-item">
              <div className="icon">
                <i className="fa-solid fa-phone-arrow-up-right"></i>
              </div>
              <div className="text">
                <h6>Phone</h6>
                <p>{settings.phones[0]}</p>
              </div>
            </a>
          </div>
        </div>
        <div className="off-canvas-sidebar-overlay" data-close="sidebar"></div>
      </div>
      <div className="off-canvas-menubar">
        <div className="off-canvas-menubar-body">
          <div className="off-canvas-head">
            <div className="off-canvas-logo">
              <Link href="/">
                <img src="/assets/img/logo/logo.svg" alt="MARWANN CHARITABLE TRUST" />
              </Link>
            </div>
            <div className="off-canvas-menubar-close" data-close="menubar">
              <i className="fa-regular fa-xmark"></i>
            </div>
          </div>
          <div className="off-canvas-menu">
            <ul>
              <li>
                <Link href="/">Home</Link>
              </li>
              <li className="has-dropdown">
                <Link href="/about">About</Link>
                <ul className="sub-menu">
                  <li>
                    <Link href="/about">About Us</Link>
                  </li>
                  <li>
                    <Link href="/our-story">Our Story</Link>
                  </li>
                  <li>
                    <Link href="/leadership">Leadership</Link>
                  </li>
                  <li>
                    <Link href="/timeline">Our Timeline</Link>
                  </li>
                  <li>
                    <Link href="/legal-recognition">{"Legal & Recognition"}</Link>
                  </li>
                </ul>
              </li>
              <li className="has-dropdown">
                <Link href="/program-areas">Work</Link>
                <ul className="sub-menu">
                  <li>
                    <Link href="/program-areas">Program Areas</Link>
                  </li>
                  <li>
                    <Link href="/active-campaigns">Active Campaigns</Link>
                  </li>
                  <li>
                    <Link href="/gallery">Photo Gallery</Link>
                  </li>
                </ul>
              </li>
              <li className="has-dropdown">
                <a href="#">Engage</a>
                <ul className="sub-menu">
                  <li>
                    <Link href="/donate">Donate</Link>
                  </li>
                  <li>
                    <Link href="/crowdfunding">Crowdfunding</Link>
                  </li>
                  <li>
                    <Link href="/volunteer">Volunteer</Link>
                  </li>
                  <li>
                    <Link href="/events">Events</Link>
                  </li>
                </ul>
              </li>
              <li>
                <Link href="/contact">Contact</Link>
              </li>
              <li className="mobile-donate-btn">
                <Link href="/donate">Donate Now →</Link>
              </li>
            </ul>
          </div>
        </div>
        <div className="off-canvas-menubar-overlay" data-close="menubar"></div>
      </div>
    </>
  )
}
