/* eslint-disable @next/next/no-img-element */
import Link from 'next/link'
import { getSettings, toTel } from '@/lib/store'
export default async function SiteFooter() {
  const settings = await getSettings()
  return (
    <>
      <footer className="footer-section footer-section-2 p-t-100 p-t-md-80 p-t-xs-70 p-b-40">
        <div className="container">
          <div className="row justify-content-between row-gap-md-5 row-gap-4 p-b-70">
            <div className="col-xl-4 col-lg-8 col-md-7">
              <div className="footer-widget">
                <div className="about-widget">
                  <div className="footer-logo">
                    <Link href="/">
                      <img src="/assets/img/logo/logo.png" alt="MARWANN CHARITABLE TRUST" />
                    </Link>
                  </div>
                  <div className="text">
                    <p>
                      MARWANN CHARITABLE TRUST is committed to empowering communities through education, healthcare, social welfare and humanitarian support.
                    </p>
                    <p>
                      <strong>We Serve God by Serving Others.</strong>
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-xl-2 col-lg-4 col-md-5">
              <div className="footer-widget">
                <h3 className="w-title">Quick Links</h3>
                <ul>
                  <li>
                    <Link href="/">Home</Link>
                  </li>
                  <li>
                    <Link href="/about">About Us</Link>
                  </li>
                  <li>
                    <Link href="/our-story">Our Story</Link>
                  </li>
                  <li>
                    <Link href="/leadership">Leadership</Link>
                  </li>
                  <li>
                    <Link href="/timeline">Our Timeline</Link>
                  </li>
                  <li>
                    <Link href="/contact">Contact Us</Link>
                  </li>
                </ul>
              </div>
            </div>
            <div className="col-xl-2 col-lg-4 col-md-5">
              <div className="footer-widget">
                <h3 className="w-title">Our Work</h3>
                <ul>
                  <li>
                    <Link href="/program-areas">Program Areas</Link>
                  </li>
                  <li>
                    <Link href="/education">Education</Link>
                  </li>
                  <li>
                    <Link href="/healthcare">Healthcare</Link>
                  </li>
                  <li>
                    <Link href="/gallery">Photo Gallery</Link>
                  </li>
                  <li>
                    <Link href="/legal-recognition">{"Legal & Recognition"}</Link>
                  </li>
                </ul>
              </div>
            </div>
            <div className="col-xl-3 col-lg-4 col-md-7">
              <div className="footer-widget">
                <h3 className="w-title">Get in Touch</h3>
                <div className="get-in-touch">
                  <Link href="/contact" className="footer-address">
                    <div className="icon">
                      <i className="fa-solid fa-location-dot"></i>
                    </div>
                    <div className="text">
                      <h6>Address</h6>
                      <p>
                        {settings.address}
                      </p>
                    </div>
                  </Link>
                  {" "}
                  <a href={`mailto:${settings.email}`} className="email">
                    <div className="icon">
                      <i className="fa-solid fa-paper-plane"></i>
                    </div>
                    <div className="text">
                      <h6>Email</h6>
                      <p>{settings.email}</p>
                    </div>
                  </a>
                  {" "}
                  {settings.phones[0] && (
                    <a href={toTel(settings.phones[0])} className="phone">
                      <div className="icon">
                        <i className="fa-solid fa-phone-arrow-up-right"></i>
                      </div>
                      <div className="text">
                        <h6>Phone</h6>
                        <p>{settings.phones[0]}</p>
                      </div>
                    </a>
                  )}
                  {" "}
                  {settings.phones[1] && (
                    <a href={toTel(settings.phones[1])} className="phone">
                      <div className="icon">
                        <i className="fa-solid fa-phone-arrow-up-right"></i>
                      </div>
                      <div className="text">
                        <h6>Additional Phone</h6>
                        <p>{settings.phones[1]}</p>
                      </div>
                    </a>
                  )}
                  {" "}
                  {settings.phones[2] && (
                    <a href={toTel(settings.phones[2])} className="phone">
                      <div className="icon">
                        <i className="fa-solid fa-phone-arrow-up-right"></i>
                      </div>
                      <div className="text">
                        <h6>Additional Phone</h6>
                        <p>{settings.phones[2]}</p>
                      </div>
                    </a>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="footer-bottom">
          <div className="row">
            <div className="col-xl-12">
              <div className="container">
                <div className="footer-bottom-layout">
                  <div className="footer-copyright">© 2026 MARWANN CHARITABLE TRUST. All Rights Reserved.</div>
                  <div className="footer-bottom-menu">
                    <ul>
                      <li>
                        <Link href="/terms">{"Terms & Conditions"}</Link>
                      </li>
                      <li>
                        <Link href="/privacy-policy">Privacy Policy</Link>
                      </li>
                      <li>
                        <a href="/admin">Admin</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </>
  )
}
